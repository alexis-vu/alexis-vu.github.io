<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

unset( $config['ripple'] );

return $config;
